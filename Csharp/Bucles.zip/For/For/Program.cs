﻿using System;

namespace For;

public class Program
{ 
    static void Main(string[] args)
    {
        /*
        Escribe un programa que realice estos pasos:
            Reciba 3 datos:
			    ancho
			    alto
			    relleno o no
            Dibuje en consola con un mismo caracter, por ejemplo *, un rectángulo de las dimensiones introducidas y use el tercer dato para discernir si el rectángulo está relleno (tiene más * dentro) o no.
            En caso de recibir el mismo número n dos veces debe dibujar un cuadrado de lado n.
            Reto: Extiende el programa anterior para recibir otro número que sea el número de cuadrados o rectángulos que se deben dibujar en la pantalla. Ejemplos:
            Input: 2,2,2, relleno = true
            Output:
            ** **
            ** **
            Input: 3, 4, 1, relleno = false
            Output:
            ***
            * *
            * *
            ***
        */

        Console.WriteLine("Ancho: ");
        int ancho = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Largo: ");
        int largo = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Relleno (1 = Si, 0 = No): ");
        int relleno = Convert.ToInt32(Console.ReadLine());

        for(int i = 0; i < largo; i++)
        { 
            for(int j = 0; j < ancho; j++)
            {
                if(relleno == 0) {
                    if (i == 0)
                    {
                        Console.Write("*");
                    }
                    else if (i == largo - 1)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        if (j == 0)
                        {
                            Console.Write("*");
                        }
                        else if (j == ancho - 1)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(" ");
                        }
                    }
                }
                else {
                    Console.Write("*");
		        }
            }
            Console.WriteLine("");
	    }
    }
}