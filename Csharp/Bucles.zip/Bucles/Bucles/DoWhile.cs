﻿using System;
namespace Bucles2
{
	public class DoWhile
	{
		static void Main2(string[] args)
		{
			/*
			Escribe un programa que realice estos pasos:
				Reciba al menos un número por consola
				Determine si el número es positivo o negativo
				Presente un contador para cada tipo (positivo y negativo).
			*/
			int pcounter = 0;
			int ncounter = 0;
			do
			{
				Console.WriteLine("Numero: ");
				int n = Convert.ToInt32(Console.ReadLine());
				if (n < 0)
				{
					pcounter++;
				}
				else
				{
					ncounter++;
				}
				Console.WriteLine("Positive: {0}\nNegative: {1}", pcounter, ncounter);
			} while (pcounter < 5 || ncounter < 5);
		}
	}
}

