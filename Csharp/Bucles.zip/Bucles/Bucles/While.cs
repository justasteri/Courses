﻿using System;

namespace Bucles
{ 
    public class While
    { 
        static void Main(string[] args)
        {
            int i = 0;
            while(i <= 10)
            {
                Console.WriteLine("1 X {0} = {1}", i, 1 * i);
                i += 1;
	        }
        }
    }
}