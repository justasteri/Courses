﻿using System;

namespace Bucles2;

public class Program
{ 
    static void Main(string[] args)
    {
        int product_price = 100;
        Console.Write("Name: ");
        string name = Console.ReadLine();
        Console.Write("\nEmail: ");
        string email = Console.ReadLine();
        Console.Write("\nCoupon: ");
        double coupon = Convert.ToDouble(Console.ReadLine());

        if(coupon > 0)
        {
            Console.WriteLine("Name: {0}\nEmail: {1}\nPrice: {2}", name, email, product_price - (product_price * (coupon / 100)));
	    } 
	    else
        { 
            Console.WriteLine("Name: {0}\nEmail: {1}\nPrice: {2}", name, email, product_price);
		}
    }
}