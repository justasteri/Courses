﻿using System;

namespace Bucles2;

public class Program
{ 
    static void Main(string[] args)
    {
        Console.WriteLine("C#");
        Console.WriteLine("Javascript");
        Console.WriteLine("Python");
        Console.WriteLine("C++");
        Console.WriteLine("R");

        Console.Write("Escoge un lenguage de programacion: ");
        int option = Convert.ToInt32(Console.ReadLine());

        switch (option)
        {
            case 1:
                Console.WriteLine("Hello, World!");
                break;
            case 2:
                Console.WriteLine("Javascript");
                break;
            case 3:
                Console.WriteLine("Python");
                break;
            case 4:
                Console.WriteLine("C++");
                break;
            case 5:
                Console.WriteLine("R");
                break;
	    }
    }
}