﻿using System;
namespace EstructurasDatos
{
	public class EmptyClass
	{
		public void Main(string[] args)
		{
			//Client myClient = new Client("Uriel Moya Mata", 441223344, "Imaginary Street 00", "test@email.com", true);
			Console.WriteLine("hola");
		}

		public struct Client
		{
			public string FullName { get; set; }
			public long Phone { get; set; }
			public string Address { get; set; }
			public string Mail { get; set; }
			public bool IsNewClient { get; set; }

			public Client(string fullname, int phone, string address, string mail, bool isNewClient)
			{
				FullName = fullname;
				Phone = phone;
				Address = address;
				Mail = mail;
				IsNewClient = isNewClient;
			}

			public override string ToString()
			{
				return $"{FullName} | {Phone} | {Address} | {Mail} | {IsNewClient}";
			}
		}
	}
}

